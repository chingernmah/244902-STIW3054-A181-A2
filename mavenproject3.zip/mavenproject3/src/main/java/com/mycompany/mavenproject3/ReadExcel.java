/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject3;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

/**
 *
 * @author Personal
 */
public class ReadExcel {

    /**
     *
     * @return
     */
    public static List<Info> readAll(){
	
	final String chessResult = "C:\\Users\\Personal\\Documents\\NetBeansProjects\\chessResultsList.xls";
	
	try {
		
		List<Info> info= new ArrayList<>();
            try (HSSFWorkbook wbook = new HSSFWorkbook ( new FileInputStream(chessResult))) {
                HSSFSheet sheet = wbook.getSheetAt(0);
                Iterator<org.apache.poi.ss.usermodel.Sheet> sheetIterator = wbook.sheetIterator();
                while (sheetIterator.hasNext()) {
                    sheet = (HSSFSheet) sheetIterator.next();
                    
                    
                    
                }       Iterator<Row> rowIterator = sheet.rowIterator();
                String no="",name="",fieldID="",fed ="",rtg="",club="";
                while (rowIterator.hasNext()) {
                    Row row = rowIterator.next();
                    
                    Cell c1 = row.getCell(0);
                    Cell c2 = row.getCell(2);
                    Cell c3 = row.getCell(3);
                    Cell c4 = row.getCell(4);
                    Cell c5 = row.getCell(5);
                    Cell c6 = row.getCell(6);
                    
                    no= String.valueOf(c1);
                    name= String.valueOf(c2);
                    fieldID= String.valueOf(c3);
                    fed= String.valueOf(c4);
                    rtg= String.valueOf(c5);
                    club= String.valueOf(c6);
                    
                    info.add(new Info (no,name,fieldID,fed,rtg,club));
                    
                    
                }
            }
        	
            return info;
       
	}catch (IOException e) {
	}
        return null;
	
	}	
    
}
