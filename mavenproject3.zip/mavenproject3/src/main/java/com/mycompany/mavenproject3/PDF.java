/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject3;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author Personal
 */
public class PDF {
    private static String file = "C:\\Users\\Personal\\Documents\\NetBeansProjects\\ChessResultLists.pdf";
	 
	 public static void main(String[] args) throws DocumentException
	   {
	    
	      try
	      {
	    	 System.out.println("PDF file is creating");
	    	 Document document;
                  document = new Document();
                  try {
                      PdfWriter.getInstance((com.itextpdf.text.Document) document, new FileOutputStream(file));
                  } catch (DocumentException ex) {
                      Logger.getLogger(PDF.class.getName()).log(Level.SEVERE, null, ex);
                  }
	        
	         PdfPTable table = new PdfPTable(new float[] { 2, 6, 2, 1, 1, 3 });
	         table.setWidthPercentage(100); 
	         table.setSpacingBefore(10f); 
	         table.setSpacingAfter(10f); 
	         
	         for (Info i : ReadExcel.readAll()) {
	                
	                table.addCell(i.getNo());
	                table.addCell(i.getName());
	                table.addCell(i.getfieldID());
	                table.addCell(i.getFed());
	                table.addCell(i.getRtg());
	                table.addCell(i.getClub());
	         }
	        
	         document.open(); 
	         
	         document.add(table);
	         
	         document.close();
	         System.out.println("PDF file is created successfully");
	         System.out.println("PDF file stored in: '\"C:\\\\Users\\\\Personal\\\\Documents\\\\NetBeansProjects\\\\ChessResultLists.pdf' ");
	         
	      } catch (Exception e)
	      {
		} 
	   }

    
    }
    

